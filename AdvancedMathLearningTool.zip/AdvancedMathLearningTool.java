import java.util.*;
public class AdvancedMathLearningTool {
	public static void main(String[] args) {
	Scanner input = new Scanner (System.in);
	Random input1=new Random();
	byte i=0;
	byte j=0;
	byte k=1;
	do{
	int x=input1.nextInt(9)+1;
	int y=input1.nextInt(9)+1;
	int z=x-y;
	boolean a= x<=y;
	if (a) continue;
    System.out.println("enter "+x+"-"+y+"  value" );
    int z1=input.nextInt();
    if (z1==z){
    System.out.println("correct");
    i++;
    }else {
    System.out.println("not correct");
    j++;
    }
    k++;
		} while(k>0 && k<6);
	System.out.println("number of correct answer is : "+i);
	System.out.println("number of wrong answer is : "+j);
	}
}